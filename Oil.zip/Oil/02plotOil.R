setwd("/home/hoanguc3m/Dropbox/Apps/Overleaf/HTVPOil/")
# library(fatBVARS)
library(ggplot2)
library(gridExtra)
library(cowplot)
library(ggthemr)
ggthemr('light')
load("~/Dropbox/WP11/Code/fattvpVAR/vignettes/Oil/OilRaw.RData")

recessions.df = read.table(textConnection(
  "Peak, Trough
  1973-11-01, 1975-03-01
  1980-01-01, 1980-07-01
  1981-07-01, 1982-11-01
  1990-07-01, 1991-03-01
  2001-03-01, 2001-11-01
  2007-12-01, 2009-06-01
  2020-03-01, 2020-05-01"), sep=',',
  colClasses=c('Date', 'Date'), header=TRUE)
data_nu <- data.frame(Time = data$time, dlogProd = data$dlogProd,
                      killian_Index = data$killian_Index,
                      lrealpoil = data$lrealpoil)

p1 <- ggplot(data_nu, aes(x = Time, y = dlogProd)) +
  geom_line(color = "#e3625b") + xlab(expression(100*Delta*"ln(Production)")) + ylab("") + ggtitle("") + theme(plot.title = element_text(hjust = 0.5)) +
  geom_rect(data=recessions.df, inherit.aes=F, aes(xmin=Peak, xmax=Trough, ymin=-Inf, ymax=+Inf), fill='darkgray', alpha=0.5) + theme_bw()

p2 <- ggplot(data_nu, aes(x = Time, y = killian_Index)) +
  geom_line(color = "#e3625b") + xlab("Kilian index") + ylab("") +
  geom_rect(data=recessions.df, inherit.aes=F, aes(xmin=Peak, xmax=Trough, ymin=-Inf, ymax=+Inf), fill='darkgray', alpha=0.5) + theme_bw()

p3 <- ggplot(data_nu, aes(x = Time, y = lrealpoil)) +
  geom_line(color = "#e3625b") + xlab("ln(Real oil price)") + ylab("") +
  geom_rect(data=recessions.df, inherit.aes=F, aes(xmin=Peak, xmax=Trough, ymin=-Inf, ymax=+Inf), fill='darkgray', alpha=0.5) + theme_bw()

pdf(file='img/data.pdf', width = 9, height = 6)
plot_grid(p1, p2, p3, ncol = 1, align = "v")
#grid.arrange(p1, p2, p3, nrow = 3, ncol = 1)
dev.off()
####################################################################
setwd("/home/hoanguc3m/Downloads/HTVPOil/")
load("G000.RData")
load("G111.RData")

library(gridExtra)
library(ggthemr)
# ggthemr('flat')
ggthemr('solarized')


####################################################################
Sigma_h111 <- G111_obj$store_Sigh
Sigma_h000 <- G000_obj$store_Sigh
ndraws <- 5000
varname <- c(expression(100*Delta*"ln(Production)"),
             "Kilian index", "ln(Real oil price)")
gg_sigma_mat <- function(i){
  data_nu <- data.frame(nu = c(Sigma_h000[,i], Sigma_h111[,i]), Models = c(rep("G000", ndraws), rep("G111", ndraws)))
  max_nu <- max(c(Sigma_h000[,i], Sigma_h111[,i]))
  data_ann <- data.frame( x = 0.5*min(data_nu[,1]) + 0.5*max(data_nu[,1]),
                          y = c(max(density(data_nu[,1])$y) *0.5 + 0.2 * sd(density(data_nu[,1])$y),
                                max(density(data_nu[,1])$y) *0.5 - 0.2 * sd(density(data_nu[,1])$y)),
                          label = c(paste("G000 : Mean =", round(mean(c(Sigma_h000[,i])),2), ", Median = ", round(median(c(Sigma_h000[,i])),2)),
                                    paste("G111 : Mean =", round(mean(c(Sigma_h111[,i])),2), ", Median = ", round(median(c(Sigma_h111[,i])),2)) ),
                          Models = c("G000","G111"))

  ggplot(data_nu) +
    geom_density(aes(x=nu, colour = Models, fill = Models, linetype = Models), alpha = 0.25, adjust = 1.5, size=1.1 ) +
    scale_colour_ggthemr_d() +
    ylab(expression(sigma[h]^2)) + xlab(varname[i])  +
    theme_light() + scale_linetype_manual(values=c("dotted", "longdash")) + theme(legend.position="bottom") +
    geom_text(data=data_ann, aes( x=x, y=y, color=Models, label=label), hjust = 0,
              fontface="bold", size = 2.5 )

}
p1 <- gg_sigma_mat(1)
p2 <- gg_sigma_mat(2)
p3 <- gg_sigma_mat(3)

setwd("/home/hoanguc3m/Dropbox/Apps/Overleaf/HTVPOil/")
pdf(file='img/postSigmah.pdf', width = 12, height = 4)
par(mar=c(2,5,3,1))
grid.arrange(p1, p2, p3, nrow = 1, ncol = 3)
dev.off()

####################################################################
Sigma_ab111 <- cbind(G111_obj$store_Sigbeta, G111_obj$store_Sigalp)
varname <- c("b[1]", "B1[1,1]", "B1[1,2]", "B1[1,3]", "B2[1,1]", "B2[1,2]", "B2[1,3]",
             "b[2]", "B1[2,1]", "B1[2,2]", "B1[2,3]", "B2[2,1]", "B2[2,2]", "B2[2,3]",
             "b[3]", "B1[3,1]", "B1[3,2]", "B1[3,3]", "B2[3,1]", "B2[3,2]", "B2[3,3]",
             "A[2,1]", "A[3,1]", "A[3,2]")

gg_sigmaAB_mat <- function(i){
  data_nu <- data.frame(nu = c((Sigma_ab111[,i])) , Models = c(rep("G111", ndraws)))
  max_nu <- (max(c(Sigma_ab111[,i])))
  ggplot(data_nu) +
    geom_density(aes(x=nu, colour = Models, fill = Models), alpha = 0.5) +
    scale_colour_ggthemr_d() +
    xlim(0,max_nu) + #geom_histogram(position = "identity", alpha = 0.8, bins = 30) +
    xlab(bquote(.(varname[i]))) + ylab(expression(sigma^2)) + theme_bw() + theme(legend.position="bottom")
}
l <- list()
for (i in c(1:24)) l[[i]] <- gg_sigmaAB_mat(i)


pdf(file='img/postSigmaAB.pdf', width = 12, height = 3*8)
par(mar=c(2,5,3,1))
plot_grid(l[[1]], l[[8]], l[[15]],
          l[[2]], l[[9]], l[[16]],
          l[[3]], l[[10]], l[[17]],
          l[[4]], l[[11]], l[[18]],
          l[[5]], l[[12]], l[[19]],
          l[[6]], l[[13]], l[[20]],
          l[[7]], l[[14]], l[[21]],
          l[[22]], l[[23]], l[[24]],
          ncol = 3, byrow = TRUE)
dev.off()

####################################################################
library(fattvpVAR)
ab111_mean <- cbind( apply(get_post(G111_obj,element = "beta"), MARGIN = c(2,3), FUN = mean),
                     apply(get_post(G111_obj,element = "alpha"), MARGIN = c(2,3), FUN = mean))
ab111_q10 <- cbind( apply(get_post(G111_obj,element = "beta"), MARGIN = c(2,3), FUN = quantile, probs = c(0.1)),
                    apply(get_post(G111_obj,element = "alpha"), MARGIN = c(2,3), FUN = quantile, probs = c(0.1)))
ab111_q90 <- cbind( apply(get_post(G111_obj,element = "beta"), MARGIN = c(2,3), FUN = quantile, probs = c(0.9)),
                    apply(get_post(G111_obj,element = "alpha"), MARGIN = c(2,3), FUN = quantile, probs = c(0.9)))

gg_TVPAB_mat <- function(i){
  Time <- tail(data$time,length(data$time) - p)

  data_nu <- data.frame(Time = Time, AB_mean = ab111_mean[,i])

  data_nu1 <- data.frame(Time = c(Time, rev(Time)) ,
                         AB_UL = c(ab111_q10[,i], rev(ab111_q90[,i])))
  x_lab_name <- bquote(.(varname[i]))
  ggplot() + geom_line(data=data_nu, mapping=aes(x=Time, y=AB_mean), color = "#ff0c00") + scale_colour_ggthemr_d() +
    geom_polygon(data=data_nu1, mapping=aes(x=Time, y=AB_UL), fill = "#5ba6d6", alpha = 0.5) +
    xlab(varname[i]) + ylab("") + theme_bw() + theme(legend.position="bottom") + theme(plot.title = element_text(hjust = 0.5)) +
    geom_rect(data=recessions.df, inherit.aes=F, aes(xmin=Peak, xmax=Trough, ymin=-Inf, ymax=+Inf), fill='darkgray', alpha=0.5)

}
varname <- parse(text = c("Intercept", "dq[t-1]", "k[t-1]", "p[t-1]", "dq[t-2]", "k[t-2]", "p[t-2]",
                          "Intercept", "dq[t-1]", "k[t-1]", "p[t-1]", "dq[t-2]", "k[t-2]", "p[t-2]",
                          "Intercept", "dq[t-1]", "k[t-1]", "p[t-1]", "dq[t-2]", "k[t-2]", "p[t-2]",
                          "dq[t]", "k[t]", "p[t]"))
l <- list()
for (i in c(1:24)) l[[i]] <- gg_TVPAB_mat(i)

pdf(file='img/postAB_eq1.pdf', width = 12, height = 3*3)
par(mar=c(2,5,3,1))
plot_grid(l[[1]], NULL, NULL,
          l[[2]], l[[3]], l[[4]],
          l[[5]], l[[6]], l[[7]],
          ncol = 3, byrow = TRUE)
dev.off()

pdf(file='img/postAB_eq2.pdf', width = 12, height = 3*3)
par(mar=c(2,5,3,1))
plot_grid(l[[8]], NULL, NULL,
          l[[9]], l[[10]], l[[11]],
          l[[12]], l[[13]], l[[14]],
          ncol = 3, byrow = TRUE)
dev.off()

pdf(file='img/postAB_eq3.pdf', width = 12, height = 3*3)
par(mar=c(2,5,3,1))
plot_grid(l[[15]], NULL, NULL,
          l[[16]], l[[17]], l[[18]],
          l[[19]], l[[20]], l[[21]],
          ncol = 3, byrow = TRUE)
dev.off()

pdf(file='img/postAB.pdf', width = 12, height = 3*8)
par(mar=c(2,5,3,1))
plot_grid(l[[1]], l[[8]], l[[15]],
          l[[2]], l[[9]], l[[16]],
          l[[3]], l[[10]], l[[17]],
          l[[4]], l[[11]], l[[18]],
          l[[5]], l[[12]], l[[19]],
          l[[6]], l[[13]], l[[20]],
          l[[7]], l[[14]], l[[21]],
          l[[22]], l[[23]], l[[24]],
          ncol = 3, byrow = TRUE)
dev.off()

#####################################################################
{
  beta_reduce_post <- get_post(G111_obj,element = "betareduce")
  rho_reduce_post <- get_post(G111_obj,element = "rho")
}
{

  ab111_mean <- cbind( apply(beta_reduce_post, MARGIN = c(2,3), FUN = mean) )
  ab111_q10 <- cbind( apply(beta_reduce_post, MARGIN = c(2,3), FUN = quantile, probs = c(0.1)) )
  ab111_q90 <- cbind( apply(beta_reduce_post, MARGIN = c(2,3), FUN = quantile, probs = c(0.9)) )

  gg_TVP_redu_AB_mat <- function(i){
    Time <- tail(data$time, length(data$time)-2)

    data_nu <- data.frame(Time = Time, AB_mean = ab111_mean[,i])

    data_nu1 <- data.frame(Time = c(Time, rev(Time)) ,
                           AB_UL = c(ab111_q10[,i], rev(ab111_q90[,i])))
    x_lab_name <- bquote(.(varname[i]))
    ggplot() + geom_line(data=data_nu, mapping=aes(x=Time, y=AB_mean), color = "#ff0c00") + scale_colour_ggthemr_d() +
      geom_polygon(data=data_nu1, mapping=aes(x=Time, y=AB_UL), fill = "#5ba6d6", alpha = 0.5) +
      xlab(varname[i]) + ylab("") + theme_bw() + theme(legend.position="bottom") + theme(plot.title = element_text(hjust = 0.5)) +
      geom_rect(data=recessions.df, inherit.aes=F, aes(xmin=Peak, xmax=Trough, ymin=-Inf, ymax=+Inf), fill='darkgray', alpha=0.5)

  }
  varname <- parse(text = c("Intercept", "dq[t-1]", "k[t-1]", "p[t-1]", "dq[t-2]", "k[t-2]", "p[t-2]",
                            "Intercept", "dq[t-1]", "k[t-1]", "p[t-1]", "dq[t-2]", "k[t-2]", "p[t-2]",
                            "Intercept", "dq[t-1]", "k[t-1]", "p[t-1]", "dq[t-2]", "k[t-2]", "p[t-2]"))
  l <- list()
  for (i in c(1:21)) l[[i]] <- gg_TVP_redu_AB_mat(i)



  pdf(file='img/post_red_AB_eq1.pdf', width = 12, height = 3*3)
  par(mar=c(2,5,3,1))
  plot_grid(l[[1]], NULL, NULL,
            l[[2]], l[[3]], l[[4]],
            l[[5]], l[[6]], l[[7]],
            ncol = 3, byrow = TRUE)
  dev.off()

  pdf(file='img/post_red_AB_eq2.pdf', width = 12, height = 3*3)
  par(mar=c(2,5,3,1))
  plot_grid(l[[8]], NULL, NULL,
            l[[9]], l[[10]], l[[11]],
            l[[12]], l[[13]], l[[14]],
            ncol = 3, byrow = TRUE)
  dev.off()

  pdf(file='img/post_red_AB_eq3.pdf', width = 12, height = 3*3)
  par(mar=c(2,5,3,1))
  plot_grid(l[[15]], NULL, NULL,
            l[[16]], l[[17]], l[[18]],
            l[[19]], l[[20]], l[[21]],
            ncol = 3, byrow = TRUE)
  dev.off()


  rho111_mean <- ( apply(rho_reduce_post, MARGIN = c(2,3), FUN = mean))
  rho111_q10 <- ( apply(rho_reduce_post, MARGIN = c(2,3), FUN = quantile, probs = c(0.1)))
  rho111_q90 <- ( apply(rho_reduce_post, MARGIN = c(2,3), FUN = quantile, probs = c(0.9)) )
  varname <- parse(text = c("rho[paste(2, ",", 1)]", "rho[paste(3, ",", 1)]", "rho[paste(3, ",", 2)]"))
  gg_H_mat <- function(i){
    Time <- tail(data$time, length(data$time)-2)

    data_nu <- data.frame(Time = Time, H_mean = rho111_mean[,i])

    data_nu1 <- data.frame(Time = c(Time, rev(Time)) ,
                           H_UL = c(rho111_q10[,i], rev(rho111_q90[,i])))
    miny <- min(rho111_q10[,i]) - 0.1
    maxy <- max(rho111_q90[,i]) + 0.1

    ggplot() + geom_line(data=data_nu, mapping=aes(x=Time, y=H_mean), color = "#ff0c00") + ylim(c(miny, maxy)) +
      geom_polygon(data=data_nu1, mapping=aes(x=Time, y=H_UL), fill = "#5ba6d6", alpha = 0.5) +
      xlab(varname[i]) + ylab("") + theme_bw() + theme(legend.position="bottom") + theme(plot.title = element_text(hjust = 0.5)) +
      geom_rect(data=recessions.df, inherit.aes=F, aes(xmin=Peak, xmax=Trough, ymin=-Inf, ymax=+Inf), fill='darkgray', alpha=0.5)

  }

  l <- list()
  for (i in c(1:3)) l[[i]] <- gg_H_mat(i)




  pdf(file='img/post_redu_rho.pdf', width = 12, height = 3)
  par(mar=c(2,5,3,1))
  plot_grid(l[[1]], l[[2]], l[[3]],
            ncol = 3, byrow = TRUE)
  dev.off()
}


####################################################################

load("/home/hoanguc3m/Downloads/HTVPOil/G000.RData")

h001_mean <- ( apply((get_post(G000_obj,element = "h")), MARGIN = c(2,3), FUN = mean))
h001_q10 <- ( apply((get_post(G000_obj,element = "h")), MARGIN = c(2,3), FUN = quantile, probs = c(0.1)))
h001_q90 <- ( apply((get_post(G000_obj,element = "h")), MARGIN = c(2,3), FUN = quantile, probs = c(0.9)) )

# h001_mean <- ( apply(exp(get_post(G000_obj,element = "h")), MARGIN = c(2,3), FUN = mean))
# h001_q10 <- ( apply(exp(get_post(G000_obj,element = "h")), MARGIN = c(2,3), FUN = quantile, probs = c(0.1)))
# h001_q90 <- ( apply(exp(get_post(G000_obj,element = "h")), MARGIN = c(2,3), FUN = quantile, probs = c(0.9)) )

varname <- c(expression("Oil-supply shock"),
             "Aggregate demand shock", "Oil-specific demand shock")
gg_H_mat <- function(i){
  Time <- tail(data$time, length(data$time)-2)

  data_nu <- data.frame(Time = Time, H_mean = h001_mean[,i])

  data_nu1 <- data.frame(Time = c(Time, rev(Time)) ,
                         H_UL = c(h001_q10[,i], rev(h001_q90[,i])))
  miny <- min(h001_q10[,i]) #- 0.3
  maxy <- max(h001_q90[,i]) + 0.3

  ggplot() + geom_line(data=data_nu, mapping=aes(x=Time, y=H_mean), color = "#ff0c00") + ylim(c(miny, maxy)) +
    geom_polygon(data=data_nu1, mapping=aes(x=Time, y=H_UL), fill = "#5ba6d6", alpha = 0.5) +
    xlab(bquote(.(varname[i]))) + ylab("") + theme_bw() + theme(legend.position="bottom") + theme(plot.title = element_text(hjust = 0.5)) +
    geom_rect(data=recessions.df, inherit.aes=F, aes(xmin=Peak, xmax=Trough, ymin=-Inf, ymax=+Inf), fill='darkgray', alpha=0.5)

}

l <- list()
for (i in c(1:3)) l[[i]] <- gg_H_mat(i)


pdf(file='img/postHG000.pdf', width = 9, height = 6)
plot_grid(l[[1]], l[[2]], l[[3]],
          ncol = 1, align = "v")
#grid.arrange(p1, p2, p3, nrow = 3, ncol = 1)
dev.off()

####################################################################

h001_mean <- ( apply(exp(0.5*get_post(G000_obj,element = "h")), MARGIN = c(2,3), FUN = mean))
h001_q10 <- ( apply(exp(0.5*get_post(G000_obj,element = "h")), MARGIN = c(2,3), FUN = quantile, probs = c(0.1)))
h001_q90 <- ( apply(exp(0.5*get_post(G000_obj,element = "h")), MARGIN = c(2,3), FUN = quantile, probs = c(0.9)) )

varname <- c(expression("Oil-supply shock"),
             "Aggregate demand shock", "Oil-specific demand")
gg_H_mat <- function(i){
  Time <- tail(data$time, length(data$time)-2)

  data_nu <- data.frame(Time = Time, H_mean = h001_mean[,i])

  data_nu1 <- data.frame(Time = c(Time, rev(Time)) ,
                         H_UL = c(h001_q10[,i], rev(h001_q90[,i])))
  miny <- 0
  maxy <- max(max(h001_q90[,i]) + 0.3, 2)

  ggplot() + geom_line(data=data_nu, mapping=aes(x=Time, y=H_mean), color = "#ff0c00") + ylim(c(miny, maxy)) +
    geom_polygon(data=data_nu1, mapping=aes(x=Time, y=H_UL), fill = "#5ba6d6", alpha = 0.5) +
    xlab(bquote(.(varname[i]))) + ylab("") + theme_bw() + theme(legend.position="bottom") + theme(plot.title = element_text(hjust = 0.5)) +
    geom_rect(data=recessions.df, inherit.aes=F, aes(xmin=Peak, xmax=Trough, ymin=-Inf, ymax=+Inf), fill='darkgray', alpha=0.5)

}

l <- list()
for (i in c(1:3)) l[[i]] <- gg_H_mat(i)

library(cowplot)

pdf(file='img/postexpHG000.pdf', width = 9, height = 6)
plot_grid(l[[1]], l[[2]], l[[3]],
          ncol = 1, align = "v")
#grid.arrange(p1, p2, p3, nrow = 3, ncol = 1)
dev.off()

###########################################################

#
# get_ht <- function(Chain, atT = NULL, n.ahead = 0, structure = TRUE){
#   # TODO: Check IRF in case of fat tail.
#   K <- ncol(Chain$data$y)
#   p <- Chain$data$p
#
#   k_alp <- K*(K-1)/2 # dimension of the impact matrix
#   k_beta <- K^2*p + K # number of VAR coefficients
#   k_beta_div_K <- K*p + 1
#   is_tv <- Chain$data$inits$is_tv
#   n_tv <- sum(is_tv)# # of time-varying equations
#
#   k_a_eq <- seq(0, K-1)
#   id_a <- cbind(cumsum(k_a_eq) - k_a_eq + 1,cumsum(k_a_eq))
#   count_seqa <- list(); count_seqb <- list()
#   count_seqa[[1]] <- 0; count_seqb[[1]] <- seq(1, k_beta_div_K)
#   for (ii in c(2:K)){
#     count_seqa[[ii]] <- seq(id_a[ii,1], id_a[ii,2])
#     count_seqb[[ii]] <- ((ii-1)*k_beta_div_K+1):(ii*k_beta_div_K)
#   }
#
#   idx_b_tv <- (kronecker(is_tv,matrix(1,nrow = K*p+1,ncol = 1))==1)   # index for time-varying betas
#   idx_a_tv <- matrix(FALSE, nrow = k_alp, ncol = 1)            # construct index for time-varying alphas
#   for (ii in 2:K){
#     if (is_tv[ii] == 1){
#       idx_a_tv[ count_seqa[[ii]]] <- TRUE
#     }
#   }
#
#
#   ndraws <- nrow(Chain$store_alp0)
#   t_max <- nrow(Chain$data$y)
#
#   if (is.null(atT)){
#     atT = t_max
#   }
#
#
#   dist <- Chain$data$dist
#   SV <- TRUE #Chain$data$priors
#
#
#   if (SV) {
#     sig <- exp(Chain$store_h[, atT, ]*0.5)
#   }
#
#   H.chol <- array(diag(K), dim = c(K,K, n.ahead+1))
#   beta <- get_post(Chain,element = "beta")
#   alp <- get_post(Chain,element = "alpha")
#
#   beta <- beta[,,-c( seq(from = 1, to = k_beta, by = k_beta_div_K) )] # Remove constant
#
#
#   out_all <- matrix(NA, nrow = K, ncol = ndraws)
#
#   # Check stable draws
#   stable_idx <- rep(FALSE, ndraws)
#   for (j in c(1:ndraws)){
#     A0 <- matrix(0, nrow = K, ncol = K)
#     A0[lower.tri(A0)] <- alp[j,atT,]
#     diag(A0) <- 1
#     A_inv <- solve(A0)
#     B_tmp = matrix(beta[j,atT,], nrow = K, byrow = T)
#     Ainv_B <- B_tmp
#     for (i in c(1:p)){
#       Ainv_B[,(K* (i-1) + 1):(K*i)] <- A_inv %*% B_tmp[,(K* (i-1) + 1):(K*i)]
#     }
#
#     if (stab_mat(B = Ainv_B, K = K, p = p) ){
#       stable_idx[j] <- TRUE
#     }
#   }
#   draw_stab <- sample((1:ndraws)[stable_idx], size = ndraws, replace = TRUE)
#
#   # Compute IR for each MC iteration
#   for (j in c(1:ndraws)){
#     samp <- draw_stab[j]
#     # Cholesky of VCV matrix, depending on specification
#
#     A0 <- matrix(0, nrow = K, ncol = K)
#     A0[lower.tri(A0)] <- alp[samp,atT,]
#     diag(A0) <- 1
#     A_inv <- solve(A0)
#
#     s = 1
#     sigtemp <- sig[samp,c(1:K)]
#
#     if (structure){
#       H.chol[,,s] <- diag(sigtemp)
#     } else {
#       H.chol[,,s] <- A_inv %*% diag(sigtemp)
#     }
#
#     out_all[,j] <- diag(H.chol[,,s])
#
#   }
#   return(list(H.chol = out_all )  )
# }
#
# G000_diagH_stdS <- parallel::mclapply(c(1:nrow(G000_obj$data$y)),
#                                       FUN = function(atT) {
#                                         get_ht(Chain = G000_obj,
#                                                atT = atT, structure = TRUE)$H.chol
#                                       },
#                                       mc.cores = 16)
# G000_diagH_stdS_structure <- array(NA, dim = dim(get_post(G000_obj,element = "h")))
# for (atT in c(1:836)){
#   G000_diagH_stdS_structure[,atT,] <- t(G000_diagH_stdS[[atT]])
# }
#
# h001_mean <- ( apply(G000_diagH_stdS_structure, MARGIN = c(2,3), FUN = mean))
# h001_q10 <- ( apply(G000_diagH_stdS_structure, MARGIN = c(2,3), FUN = quantile, probs = c(0.1)))
# h001_q90 <- ( apply(G000_diagH_stdS_structure, MARGIN = c(2,3), FUN = quantile, probs = c(0.9)) )
#
# varname <- c("3m dlogProd", "Slope", "BAA spread")
# gg_H_mat <- function(i){
#   Time <- tail(seq(as.Date("1953/04/01"), as.Date("2023/02/01"), "months"), nrow(h001_mean))
#
#   data_nu <- data.frame(Time = Time, H_mean = h001_mean[,i])
#
#   data_nu1 <- data.frame(Time = c(Time, rev(Time)) ,
#                          H_UL = c(h001_q10[,i], rev(h001_q90[,i])))
#   miny <- min(h001_q10[,i]) #- 0.3
#   #maxy <- max(h001_q90[,i]) + 0.3
#   maxy <- 2.5
#
#   ggplot() + geom_line(data=data_nu, mapping=aes(x=Time, y=H_mean), color = "#ff0c00") + ylim(c(miny, maxy)) +
#     geom_polygon(data=data_nu1, mapping=aes(x=Time, y=H_UL), fill = "#5ba6d6", alpha = 0.5) +
#     xlab(bquote(.(varname[i]))) + ylab("") + theme_bw() + theme(legend.position="bottom") + theme(plot.title = element_text(hjust = 0.5)) +
#     geom_rect(data=recessions.df, inherit.aes=F, aes(xmin=Peak, xmax=Trough, ymin=-Inf, ymax=+Inf), fill='darkgray', alpha=0.5)
#
# }
#
# l <- list()
# for (i in c(1:3)) l[[i]] <- gg_H_mat(i)
#
# setwd("/home/hoanguc3m/Dropbox/WP11/")
# pdf(file='img/postexpHG000div2.pdf', width = 9, height = 6)
# plot_grid(l[[1]], l[[2]], l[[3]],
#           ncol = 1, align = "v")
# #grid.arrange(p1, p2, p3, nrow = 3, ncol = 1)
# dev.off()



#################################################################
# Post Analysis
#################################################################

#  Effective samples
str(inits)
#List of 3
# $ samples: num 100000
# $ burnin : num 20000
# $ thin   : num 20

# A total of 5000 samples
effectiveSize(G000_obj$store_Sigbeta)
# var21     var22
# 1129.0367  590.8422
# var23     var24     var25     var26     var27     var28     var29     var30
# 1227.1316  541.3256  592.7537 2274.1869  986.8282  994.1264 3580.2024 1322.9055

# A total of 5000 samples
effectiveSize(G000_obj$store_Sigalp)
#    var1     var2     var3
# 0.0000 855.8660 991.5724
effectiveSize(G000_obj$store_Sigh)
# var1     var2     var3
# 682.2615 992.2573 285.6542
effectiveSize(G000_obj$store_beta0)
effectiveSize(G000_obj$store_alp0)
effectiveSize(G000_obj$store_h0)
effectiveSize(G000_obj$store_nu)

#########################
# A total of 5000 samples

