library(readxl)
library(Matrix)
library(fattvpVAR)
library(profvis)
library(invgamma)
# dataraw <- read_excel("~/Dropbox/WP11/Code/fattvpVAR/vignettes/Oil/Data 231019.xlsx",
#                       col_types = c("text", "numeric", "numeric",
#                                     "numeric", "numeric", "numeric",
#                                     "numeric", "numeric"))
#
# p <- 2 # number of lags
# t_max <- nrow(dataraw)
# time <- seq(as.Date("1973/02/01"), as.Date("2023/05/01"), "months")
# dlogProd <- 100 * (log(dataraw$PROD_OIL[38:t_max]) - log(dataraw$PROD_OIL[37:(t_max-1)]))
# killian_Index <- dataraw$KILIAN[38:t_max]
# lrealpoil <- log(dataraw$REAL_PRICE_OIL[38:t_max])
# data <- data.frame(time = time, dlogProd = dlogProd,
#                    killian_Index = killian_Index, lrealpoil = lrealpoil)
# t_max <- atT <-  nrow(data)
# y <- data.matrix(data[(p+1):atT,c(2:4)])
# y0 <- data.matrix(data[1:p,c(2:4)])
# priors <- get_prior_minnesota(y = y, p = p, intercept=TRUE)
# inits <- list(samples = 100000, burnin = 20000, thin = 20)
# save.image("~/Dropbox/WP11/Code/fattvpVAR/vignettes/Oil/OilRaw.RData")
RhpcBLASctl::blas_set_num_threads(2)
load("~/Dropbox/WP11/Code/fattvpVAR/vignettes/Oil/OilRaw.RData")
setwd("/home/hoanguc3m/Downloads/HTVPOil/")
####################################################################
{


inits$is_tv = c(0,0,0); G000_obj <- fitTVPGaussSV_ASIS(y, y0, p, priors, inits)
save(G000_obj, file = "G000.RData")

# inits$is_tv = c(0,0,0); G000_NCP <- fitTVPGaussSV_NCP(y, y0, p, priors, inits)
# save(G000_NCP, file = "G000_NCP.RData")

inits$is_tv = c(0,0,1); G001_obj <- fitTVPGaussSV_ASIS(y, y0, p, priors, inits)
save(G001_obj, file = "G001.RData")


inits$is_tv = c(0,1,0); G010_obj <- fitTVPGaussSV_ASIS(y, y0, p, priors, inits)
save(G010_obj, file = "G010.RData")

inits$is_tv = c(1,0,0); G100_obj <- fitTVPGaussSV_ASIS(y, y0, p, priors, inits)
save(G100_obj, file = "G100.RData")

inits$is_tv = c(1,1,0); G110_obj <- fitTVPGaussSV_ASIS(y, y0, p, priors, inits)
save(G110_obj, file = "G110.RData")

inits$is_tv = c(0,1,1); G011_obj <- fitTVPGaussSV_ASIS(y, y0, p, priors, inits)
save(G011_obj, file = "G011.RData")

inits$is_tv = c(1,0,1); G101_obj <- fitTVPGaussSV_ASIS(y, y0, p, priors, inits)
save(G101_obj, file = "G101.RData")
#inits$samples <- 20000
# inits$samples <- 20000
# inits$thin <- 1
inits$is_tv = c(1,1,1); G111_obj <- fitTVPGaussSV_ASIS(y, y0, p, priors, inits)
save(G111_obj, file = "G111.RData")

# inits$is_tv = c(1,1,1); G111_NCP <- fitTVPGaussSV_NCP(y, y0, p, priors, inits)
# save(G111_NCP, file = "G111_NCP.RData")

}
{
  numCores = 15
  load("G000.RData")
  G000_ML_Ent <- MLEnt_TVPGSV(Chain = G000_obj, numCores = numCores)
  save(G000_ML_Ent, file = "G000_ML_Ent.RData")
  rm(G000_ML_Ent, G000_obj)

  load("G001.RData")
  G001_ML_Ent <- MLEnt_TVPGSV(Chain = G001_obj, numCores = numCores)
  save(G001_ML_Ent, file = "G001_ML_Ent.RData")
  rm(G001_ML_Ent, G001_obj)

  load("G010.RData")
  G010_ML_Ent <- MLEnt_TVPGSV(Chain = G010_obj, numCores = numCores)
  save(G010_ML_Ent, file = "G010_ML_Ent.RData")
  rm(G010_ML_Ent, G010_obj)

  load("G100.RData")
  G100_ML_Ent <- MLEnt_TVPGSV(Chain = G100_obj, numCores = numCores)
  save(G100_ML_Ent, file = "G100_ML_Ent.RData")
  rm(G100_ML_Ent, G100_obj)

  load("G011.RData")
  G011_ML_Ent <- MLEnt_TVPGSV(Chain = G011_obj, numCores = numCores)
  save(G011_ML_Ent, file = "G011_ML_Ent.RData")

  load("G101.RData")
  G101_ML_Ent <- MLEnt_TVPGSV(Chain = G101_obj, numCores = numCores)
  save(G101_ML_Ent, file = "G101_ML_Ent.RData")

  load("G110.RData")
  G110_ML_Ent <- MLEnt_TVPGSV(Chain = G110_obj, numCores = numCores)
  save(G110_ML_Ent, file = "G110_ML_Ent.RData")

  load("G111.RData")
  G111_ML_Ent <- MLEnt_TVPGSV(Chain = G111_obj, numCores = numCores)
  save(G111_ML_Ent, file = "G111_ML_Ent.RData")
}
####################################################################
{


  inits$is_tv = c(0,0,0); G000nonSV_obj <- fitTVPGaussnonSV_ASIS(y, y0, p, priors, inits)
  save(G000nonSV_obj, file = "G000nonSV.RData")

  # inits$is_tv = c(0,0,0); G000_NCP <- fitTVPGaussnonSV_NCP(y, y0, p, priors, inits)
  # save(G000_NCP, file = "G000_NCPnonSV.RData")

  inits$is_tv = c(0,0,1); G001nonSV_obj <- fitTVPGaussnonSV_ASIS(y, y0, p, priors, inits)
  save(G001nonSV_obj, file = "G001nonSV.RData")


  inits$is_tv = c(0,1,0); G010nonSV_obj <- fitTVPGaussnonSV_ASIS(y, y0, p, priors, inits)
  save(G010nonSV_obj, file = "G010nonSV.RData")

  inits$is_tv = c(1,0,0); G100nonSV_obj <- fitTVPGaussnonSV_ASIS(y, y0, p, priors, inits)
  save(G100nonSV_obj, file = "G100nonSV.RData")

  inits$is_tv = c(1,1,0); G110nonSV_obj <- fitTVPGaussnonSV_ASIS(y, y0, p, priors, inits)
  save(G110nonSV_obj, file = "G110nonSV.RData")

  inits$is_tv = c(0,1,1); G011nonSV_obj <- fitTVPGaussnonSV_ASIS(y, y0, p, priors, inits)
  save(G011nonSV_obj, file = "G011nonSV.RData")

  inits$is_tv = c(1,0,1); G101nonSV_obj <- fitTVPGaussnonSV_ASIS(y, y0, p, priors, inits)
  save(G101nonSV_obj, file = "G101nonSV.RData")
  #inits$samples <- 20000
  # inits$samples <- 20000
  # inits$thin <- 1
  inits$is_tv = c(1,1,1); G111nonSV_obj <- fitTVPGaussnonSV_ASIS(y, y0, p, priors, inits)
  save(G111nonSV_obj, file = "G111nonSV.RData")

}
{
  numCores = 15
  load("G000nonSV.RData")
  G000_ML_Ent <- MLEnt_TVPGnonSV(Chain = G000nonSV_obj, numCores = numCores)
  save(G000_ML_Ent, file = "G000_ML_EntnonSV.RData")
  rm(G000_ML_Ent, G000nonSV_obj)

  load("G001nonSV.RData")
  G001_ML_Ent <- MLEnt_TVPGnonSV(Chain = G001nonSV_obj, numCores = numCores)
  save(G001_ML_Ent, file = "G001_ML_EntnonSV.RData")
  rm(G001_ML_Ent, G001nonSV_obj)

  load("G010nonSV.RData")
  G010_ML_Ent <- MLEnt_TVPGnonSV(Chain = G010nonSV_obj, numCores = numCores)
  save(G010_ML_Ent, file = "G010_ML_EntnonSV.RData")
  rm(G010_ML_Ent, G010nonSV_obj)

  load("G100nonSV.RData")
  G100_ML_Ent <- MLEnt_TVPGnonSV(Chain = G100nonSV_obj, numCores = numCores)
  save(G100_ML_Ent, file = "G100_ML_EntnonSV.RData")
  rm(G100_ML_Ent, G100nonSV_obj)

  load("G011nonSV.RData")
  G011_ML_Ent <- MLEnt_TVPGnonSV(Chain = G011nonSV_obj, numCores = numCores)
  save(G011_ML_Ent, file = "G011_ML_EntnonSV.RData")
  rm(G011_ML_Ent, G011nonSV_obj)

  load("G101nonSV.RData")
  G101_ML_Ent <- MLEnt_TVPGnonSV(Chain = G101nonSV_obj, numCores = numCores)
  save(G101_ML_Ent, file = "G101_ML_EntnonSV.RData")
  rm(G101_ML_Ent, G101nonSV_obj)

  load("G110nonSV.RData")
  G110_ML_Ent <- MLEnt_TVPGnonSV(Chain = G110nonSV_obj, numCores = numCores)
  save(G110_ML_Ent, file = "G110_ML_EntnonSV.RData")
  rm(G110_ML_Ent, G110nonSV_obj)

  load("G111nonSV.RData")
  G111_ML_Ent <- MLEnt_TVPGnonSV(Chain = G111nonSV_obj, numCores = numCores)
  save(G111_ML_Ent, file = "G111_ML_EntnonSV.RData")
  rm(G111_ML_Ent, G111nonSV_obj)
}

{
  setwd("/home/hoanguc3m/Downloads/HTVPOil/")
  load("G000_ML_Ent.RData"); load("G001_ML_Ent.RData"); load("G010_ML_Ent.RData"); load("G100_ML_Ent.RData")
  load("G011_ML_Ent.RData"); load("G101_ML_Ent.RData"); load("G110_ML_Ent.RData"); load("G111_ML_Ent.RData")

  xtable::xtable(
    round(matrix(c(G000_ML_Ent$LL, G100_ML_Ent$LL, G010_ML_Ent$LL, G001_ML_Ent$LL, G110_ML_Ent$LL, G101_ML_Ent$LL, G011_ML_Ent$LL, G111_ML_Ent$LL), nrow = 1), digits = 2)
  )
  load("G000_ML_EntnonSV.RData"); load("G001_ML_EntnonSV.RData"); load("G010_ML_EntnonSV.RData"); load("G100_ML_EntnonSV.RData")
  load("G011_ML_EntnonSV.RData"); load("G101_ML_EntnonSV.RData"); load("G110_ML_EntnonSV.RData"); load("G111_ML_EntnonSV.RData")
  xtable::xtable(
    round(matrix(c(G000_ML_Ent$LL, G100_ML_Ent$LL, G010_ML_Ent$LL, G001_ML_Ent$LL, G110_ML_Ent$LL, G101_ML_Ent$LL, G011_ML_Ent$LL, G111_ML_Ent$LL), nrow = 1), digits = 2)
  )

}
